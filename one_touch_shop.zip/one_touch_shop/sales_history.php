<?php include 'includes/session.php'; ?>
<?php
    if(!isset($_SESSION['user'])){
        header('location: index.php');
        exit();
    }
?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    
    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="row">
                    <div class="col-sm-12">
                        <h2 class="page-header"><i class="fa fa-history"></i> My Order Updates</h2>
                        
                        <?php
                        if(isset($_SESSION['error'])){
                          echo "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><h4><i class='icon fa fa-warning'></i> Error!</h4>".$_SESSION['error']."</div>";
                          unset($_SESSION['error']);
                        }
                        if(isset($_SESSION['success'])){
                          echo "<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><h4><i class='icon fa fa-check'></i> Success!</h4>".$_SESSION['success']."</div>";
                          unset($_SESSION['success']);
                        }
                        ?>

                        <div class="box box-solid">
                            <div class="box-header with-border">
                                <h3 class="box-title">Order History</h3>
                                <div class="pull-right">
                                    <a href="index.php" class="btn btn-xs btn-primary btn-flat"><i class="fa fa-shopping-cart"></i> Continue Shopping</a>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="example1">
                                        <thead>
                                            <th class="hidden"></th>
                                            <th>Date</th>
                                            <th>Transaction ID</th>
                                            <th>Amount (KSh)</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $conn = $pdo->open();
                                            try{
                                                $stmt = $conn->prepare("SELECT * FROM sales WHERE user_id=:user_id ORDER BY sales_date DESC");
                                                $stmt->execute(['user_id'=>$user['id']]);
                                                
                                                foreach($stmt as $row){
                                                    // Dynamic Total Calculation
                                                    $stmt_details = $conn->prepare("SELECT * FROM details LEFT JOIN products ON products.id=details.product_id WHERE sales_id=:id");
                                                    $stmt_details->execute(['id'=>$row['id']]);
                                                    $total_amount = 0;
                                                    foreach($stmt_details as $row_details){
                                                        $subtotal = $row_details['price'] * $row_details['quantity'];
                                                        $total_amount += $subtotal;
                                                    }

                                                    // Status Sync logic
                                                    $status = (int)$row['status'];
                                                    $cancel_btn = "";
                                                    
                                                    switch($status){
                                                        case 1: // SHIPPED
                                                            $status_label = "<span class='label label-info'><i class='fa fa-ship'></i> SHIPPED</span>";
                                                            break;
                                                        case 2: // DELIVERED
                                                            $status_label = "<span class='label label-success'><i class='fa fa-check-circle'></i> DELIVERED</span>";
                                                            break;
                                                        case 3: // CANCELLED
                                                            $status_label = "<span class='label label-danger'><i class='fa fa-times-circle'></i> CANCELLED</span>";
                                                            break;
                                                        default: // PENDING
                                                            $status_label = "<span class='label label-warning'><i class='fa fa-clock-o'></i> PENDING</span>";
                                                            $cancel_btn = "<button class='btn btn-xs btn-danger btn-flat cancel_order' data-id='".$row['id']."'><i class='fa fa-trash'></i> Cancel</button>";
                                                            break;
                                                    }

                                                    echo "
                                                        <tr>
                                                            <td class='hidden'></td>
                                                            <td>".date('M d, Y', strtotime($row['sales_date']))."</td>
                                                            <td>".$row['pay_id']."</td>
                                                            <td><b>KSh ".number_format($total_amount, 2)."</b></td>
                                                            <td>".$status_label."</td>
                                                            <td>
                                                                <button class='btn btn-xs btn-info btn-flat transact' data-id='".$row['id']."' title='View Details'><i class='fa fa-search'></i> View</button>
                                                                <a href='sales_print.php?id=".$row['id']."' class='btn btn-xs btn-success btn-flat' target='_blank' title='Download PDF'><i class='fa fa-print'></i> PDF</a>
                                                                ".$cancel_btn."
                                                            </td>
                                                        </tr>
                                                    ";
                                                }
                                            }
                                            catch(PDOException $e){ echo "Error: " . $e->getMessage(); }
                                            $pdo->close();
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="modal fade" id="transaction">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"><b>Order Items</b></h4>
                </div>
                <div class="modal-body">
                  <p>Date: <span id="date"></span> <span class="pull-right">Trans#: <span id="transid"></span></span></p>
                  <table class="table table-bordered">
                    <thead><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></thead>
                    <tbody id="detail"></tbody>
                    <tfoot>
                        <tr><td colspan="3" align="right"><b>Grand Total</b></td><td><span id="total"></span></td></tr>
                    </tfoot>
                  </table>
                  <p class="text-muted"><small>* If delivered, click the product name to leave a review.</small></p>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cancel_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="order_cancel.php">
                    <input type="hidden" class="sales_id" name="id">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title"><b>Cancel Order</b></h4>
                    </div>
                    <div class="modal-body">
                      <p>Are you sure you want to cancel this order? This cannot be undone.</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">No</button>
                      <button type="submit" class="btn btn-danger btn-flat" name="cancel">Yes, Cancel Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>

<script>
$(function(){
  // Load Transaction Details
  $(document).on('click', '.transact', function(e){
    e.preventDefault();
    $('#transaction').modal('show');
    var id = $(this).data('id');
    $.ajax({
      type: 'POST',
      url: 'transaction.php',
      data: {id:id},
      dataType: 'json',
      success:function(response){
        $('#date').html(response.date);
        $('#transid').html(response.transaction);
        $('#detail').html(response.list);
        $('#total').html(response.total);
      }
    });
  });

  // Cancel Order Trigger
  $(document).on('click', '.cancel_order', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    $('.sales_id').val(id);
    $('#cancel_modal').modal('show');
  });
});
</script>
</body>
</html>