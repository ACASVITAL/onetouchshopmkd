<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="row">
                    <div class="col-sm-12">
                        <h1 class="page-header">My Complaints</h1>
                        
                        <?php
                        if(!isset($_SESSION['user'])){
                            echo "<h4>Please <a href='login.php'>Login</a> to view and submit complaints.</h4>";
                        } else {
                            ?>
                            <div class="box box-solid">
                                <div class="box-header with-border">
                                    <a href="contact.php" class="btn btn-primary btn-flat btn-sm"><i class="fa fa-plus"></i> New Complaint</a>
                                </div>
                                <div class="box-body">
                                    <table class="table table-bordered" id="example1">
                                        <thead>
                                            <th>Date Submitted</th>
                                            <th>Subject</th>
                                            <th>My Message</th>
                                            <th>Admin Response</th>
                                            <th>Status</th>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $conn = $pdo->open();
                                            try{
                                                $stmt = $conn->prepare("SELECT * FROM complaints WHERE user_id=:user_id ORDER BY created_on DESC");
                                                $stmt->execute(['user_id'=>$user['id']]);
                                                foreach($stmt as $row){
                                                    // Status Label logic
                                                    $status = ($row['status']) ? '<span class="label label-success">Resolved</span>' : '<span class="label label-danger">Pending</span>';
                                                    
                                                    // Admin Reply formatting
                                                    if(!empty($row['admin_reply'])){
                                                        $reply = "
                                                            <div class='callout callout-info' style='margin:0; padding: 10px;'>
                                                                <p style='font-size: 13px;'>".$row['admin_reply']."</p>
                                                            </div>
                                                        ";
                                                    } else {
                                                        $reply = "<span class='text-muted'><i>Waiting for admin response...</i></span>";
                                                    }
                                                    
                                                    echo "
                                                        <tr>
                                                            <td>".date('M d, Y', strtotime($row['created_on']))."</td>
                                                            <td>".$row['subject']."</td>
                                                            <td>".$row['message']."</td>
                                                            <td>".$reply."</td>
                                                            <td>".$status."</td>
                                                        </tr>
                                                    ";
                                                }
                                            }
                                            catch(PDOException $e){
                                                echo $e->getMessage();
                                            }
                                            $pdo->close();
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php include 'includes/footer.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
</body>
</html>