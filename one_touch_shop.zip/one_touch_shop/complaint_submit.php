<?php
    include 'includes/session.php';

    if(isset($_POST['send'])){
        $subject = $_POST['subject'];
        $message = $_POST['message'];
        $userid = $user['id']; // Assumes your user session stores data in $user

        $conn = $pdo->open();
        try{
            $stmt = $conn->prepare("INSERT INTO complaints (user_id, subject, message) VALUES (:user, :sub, :msg)");
            $stmt->execute(['user'=>$userid, 'sub'=>$subject, 'msg'=>$message]);
            $_SESSION['success'] = 'Complaint sent successfully';
        }
        catch(PDOException $e){
            $_SESSION['error'] = $e->getMessage();
        }
        $pdo->close();
    }
    header('location: contact.php');
?>