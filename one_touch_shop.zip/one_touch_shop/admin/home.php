<?php 
  // 1. Force error reporting at the absolute top
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  include 'includes/session.php';
  include 'includes/format.php'; 

  $today = date('Y-m-d');
  $year = (isset($_GET['year'])) ? $_GET['year'] : date('Y');

  // 2. Open Connection once
  $conn = $pdo->open();
?>

<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>Dashboard - <?php echo $year; ?></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <section class="content">
      <?php
        // Handling Session Alerts
        foreach(['error', 'success'] as $msg){
          if(isset($_SESSION[$msg])){
            $icon = ($msg == 'error') ? 'warning' : 'check';
            $class = ($msg == 'error') ? 'danger' : 'success';
            echo "
              <div class='alert alert-$class alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4><i class='icon fa fa-$icon'></i> ".ucfirst($msg)."!</h4>
                ".$_SESSION[$msg]."
              </div>
            ";
            unset($_SESSION[$msg]);
          }
        }
      ?>

      <div class="row">
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <?php
                try {
                  $stmt = $conn->prepare("SELECT * FROM details LEFT JOIN products ON products.id=details.product_id");
                  $stmt->execute();
                  $total = 0;
                  foreach($stmt as $srow){
                    $total += $srow['price'] * $srow['quantity'];
                  }
                  echo "<h3>Ksh ".number_format($total, 2)."</h3>";
                } catch(PDOException $e) { echo "<h3>Error</h3>"; }
              ?>
              <p>Total Sales</p>
            </div>
            <div class="icon"><i class="fa fa-shopping-cart"></i></div>
            <a href="sales.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <?php
                $stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM products");
                $stmt->execute();
                $prow = $stmt->fetch();
                echo "<h3>".($prow['numrows'] ?? 0)."</h3>";
              ?>
              <p>Number of Products</p>
            </div>
            <div class="icon"><i class="fa fa-barcode"></i></div>
            <a href="products.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner">
              <?php
                $stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM users");
                $stmt->execute();
                $urow = $stmt->fetch();
                echo "<h3>".($urow['numrows'] ?? 0)."</h3>";
              ?>
              <p>Number of Users</p>
            </div>
            <div class="icon"><i class="fa fa-users"></i></div>
            <a href="users.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-red">
            <div class="inner">
              <?php
                try {
                  $stmt = $conn->prepare("SELECT * FROM details LEFT JOIN sales ON sales.id=details.sales_id LEFT JOIN products ON products.id=details.product_id WHERE sales_date=:sales_date");
                  $stmt->execute(['sales_date'=>$today]);
                  $total_today = 0;
                  foreach($stmt as $trow){
                    $total_today += $trow['price'] * $trow['quantity'];
                  }
                  echo "<h3>Ksh ".number_format($total_today, 2)."</h3>";
                } catch(PDOException $e) { echo "<h3>Ksh 0.00</h3>"; }
              ?>
              <p>Sales Today</p>
            </div>
            <div class="icon"><i class="fa fa-money"></i></div>
            <a href="sales.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Monthly Sales Report</h3>
              <div class="box-tools pull-right">
                <form class="form-inline">
                  <div class="form-group">
                    <label>Select Year: </label>
                    <select class="form-control input-sm" id="select_year">
                      <?php
                        for($i=2020; $i<=2030; $i++){
                          $selected = ($i==$year)?'selected':'';
                          echo "<option value='".$i."' ".$selected.">".$i."</option>";
                        }
                      ?>
                    </select>
                  </div>
                </form>
              </div>
            </div>
            <div class="box-body">
              <div class="chart">
                <br>
                <div id="legend" class="text-center"></div>
                <canvas id="barChart" style="height:350px"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <?php include 'includes/footer.php'; ?>
</div>

<?php
  // 3. Process Chart Data
  $months = array();
  $sales = array();
  for( $m = 1; $m <= 12; $m++ ) {
    try{
      $stmt = $conn->prepare("SELECT * FROM details LEFT JOIN sales ON sales.id=details.sales_id LEFT JOIN products ON products.id=details.product_id WHERE MONTH(sales_date)=:month AND YEAR(sales_date)=:year");
      $stmt->execute(['month'=>$m, 'year'=>$year]);
      $sub_total = 0;
      foreach($stmt as $srow){
        $sub_total += $srow['price'] * $srow['quantity'];    
      }
      array_push($sales, round($sub_total, 2));
    }
    catch(PDOException $e){
      array_push($sales, 0);
    }
    $months[] = date('M', mktime(0, 0, 0, $m, 1));
  }

  $months_json = json_encode($months);
  $sales_json = json_encode($sales);

  $pdo->close(); // Close connection after logic
?>

<?php include 'includes/scripts.php'; ?>

<script>
$(function(){
  var barChartCanvas = $('#barChart').get(0).getContext('2d')
  var barChart = new Chart(barChartCanvas)
  var barChartData = {
    labels  : <?php echo $months_json; ?>,
    datasets: [
      {
        label               : 'SALES (Ksh)',
        fillColor           : 'rgba(60,141,188,0.9)',
        strokeColor         : 'rgba(60,141,188,0.8)',
        pointColor          : '#3b8bba',
        pointStrokeColor    : 'rgba(60,141,188,1)',
        pointHighlightFill  : '#fff',
        pointHighlightStroke: 'rgba(60,141,188,1)',
        data                : <?php echo $sales_json; ?>
      }
    ]
  }
  
  var barChartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    datasetFill: false
  }
  
  var myChart = barChart.Bar(barChartData, barChartOptions);
  // Fixed Legend Generation
  if(myChart.generateLegend) {
      $('#legend').html(myChart.generateLegend());
  }
});

$(function(){
  $('#select_year').change(function(){
    window.location.href = 'home.php?year='+$(this).val();
  });
});
</script>
</body>
</html>