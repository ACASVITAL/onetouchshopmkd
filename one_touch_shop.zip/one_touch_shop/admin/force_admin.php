<?php
include '../includes/conn.php';
$conn = $pdo->open();

$email = 'brianmwololo@gmail.com';
$password = 'admin123';
$hashed = password_hash($password, PASSWORD_DEFAULT);

try {
    // 1. Delete any existing entry to start fresh
    $stmt = $conn->prepare("DELETE FROM users WHERE email = :email");
    $stmt->execute(['email'=>$email]);

    // 2. Insert the clean admin account
    $stmt = $conn->prepare("INSERT INTO users (email, password, firstname, lastname, type, status, created_on) 
                            VALUES (:email, :password, :firstname, :lastname, :type, :status, :created_on)");
    
    $stmt->execute([
        'email' => $email,
        'password' => $hashed,
        'firstname' => 'Brian',
        'lastname' => 'Mwololo',
        'type' => 1,
        'status' => 1,
        'created_on' => date('Y-m-d')
    ]);

    echo "<h2>Success!</h2>";
    echo "Account for <b>$email</b> has been created fresh.<br>";
    echo "Password is: <b>admin123</b><br>";
    echo "<a href='login.php'>Go to Login Page</a>";

} catch(PDOException $e) {
    echo "DB Error: " . $e->getMessage();
}

$pdo->close();
?>