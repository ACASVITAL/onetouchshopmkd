<?php
$password_plain = 'admin123';
$stored_hash = '$2y$10$f5YI7M/YV8K5vHpxxOEuV6z5V3lP1q.j5.pP4W.fG/jJmH9P/yW';

if (password_verify($password_plain, $stored_hash)) {
    echo "Password is VALID. The issue is likely how the data is being fetched from your DB.";
} else {
    echo "Password is INVALID. There might be a copy-paste error in the hash string.";
}
?>