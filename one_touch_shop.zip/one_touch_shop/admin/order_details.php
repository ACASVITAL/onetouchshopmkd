<?php
  include 'includes/session.php';

  if(!isset($_POST['id'])){
      die(json_encode(['list' => 'No ID provided']));
  }

  $id = $_POST['id'];
  $conn = $pdo->open();

  $output = array(
        'list'=>'', 'name'=>'', 'email'=>'', 'phone'=>'', 
        'address'=>'', 'transaction'=>'', 'total'=>'', 'status'=>'', 
        'contact_link'=>'', 'whatsapp_link'=>'', 'map_link'=>''
    );

  try {
    // 1. Fetch Order and User details once
    $stmt = $conn->prepare("SELECT *, sales.id AS salesid FROM sales LEFT JOIN users ON users.id=sales.user_id WHERE sales.id=:id");
    $stmt->execute(['id'=>$id]);
    $order = $stmt->fetch();

    if($order){
        $output['name'] = $order['firstname'].' '.$order['lastname'];
        $output['email'] = $order['email'];
        $output['transaction'] = $order['pay_id'];
        $output['status'] = $order['status'] ?? 'Pending';

        // --- Contact Logic ---
        $phone = (!empty($order['contact_info'])) ? $order['contact_info'] : '';
        $output['phone'] = $phone;
        if(!empty($phone)){
            $output['contact_link'] = "tel:".$phone;
            $clean_phone = preg_replace('/[^0-9]/', '', $phone);
            if(substr($clean_phone, 0, 1) == '0'){
                $clean_phone = '254' . substr($clean_phone, 1);
            }
            $output['whatsapp_link'] = "https://wa.me/".$clean_phone;
        }

        // --- Address Logic ---
        $address = (!empty($order['address'])) ? $order['address'] : 'No Address Stored';
        $output['address'] = $address;
        $output['map_link'] = "https://www.google.com/maps/search/?api=1&query=".urlencode($address);

        // 2. Fetch Product list for this order
        $stmt = $conn->prepare("SELECT *, details.quantity AS qty FROM details LEFT JOIN products ON products.id=details.product_id WHERE details.sales_id=:id");
        $stmt->execute(['id'=>$id]);

        $total = 0;
        foreach($stmt as $row){
          $subtotal = $row['price'] * $row['qty'];
          $total += $subtotal;
          $output['list'] .= "
            <tr>
              <td>".$row['name']."</td>
              <td>KSh ".number_format($row['price'], 2)."</td>
              <td>".$row['qty']."</td>
              <td>KSh ".number_format($subtotal, 2)."</td>
            </tr>
          ";
        }
        $output['total'] = 'KSh '.number_format($total, 2);
    }
  }
  catch(PDOException $e) {
    $output['error'] = true;
    $output['list'] = "Error: " . $e->getMessage();
  }

  $pdo->close();
  echo json_encode($output);
?>