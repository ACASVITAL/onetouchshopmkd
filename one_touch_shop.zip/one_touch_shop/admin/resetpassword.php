<?php
include '../includes/conn.php';
session_start();

if(isset($_POST['reset'])){
    $email = $_POST['email'];
    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $conn = $pdo->open();
    try {
        $stmt = $conn->prepare("UPDATE users SET password=:password WHERE email=:email");
        $stmt->execute(['password'=>$new_password, 'email'=>$email]);
        $_SESSION['success'] = 'Password updated successfully';
        header('location: login.php');
    } catch(PDOException $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    $pdo->close();
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4 card p-4">
            <h4>Reset Password</h4>
            <form method="POST">
                <input type="email" name="email" placeholder="Your Admin Email" class="form-control mb-2" required>
                <input type="password" name="password" placeholder="New Password" class="form-control mb-2" required>
                <button type="submit" name="reset" class="btn btn-warning btn-block">Update Password</button>
            </form>
            <a href="login.php" class="mt-2 d-block text-center">Back to Login</a>
        </div>
    </div>
</div>
</body>
</html>