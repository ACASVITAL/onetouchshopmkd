<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <div class="content-wrapper">
    <section class="content-header"><h1>Customer Orders</h1></section>
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){ echo "<div class='alert alert-danger'>".$_SESSION['error']."</div>"; unset($_SESSION['error']); }
        if(isset($_SESSION['success'])){ echo "<div class='alert alert-success'>".$_SESSION['success']."</div>"; unset($_SESSION['success']); }
      ?>
      <div class="box"><div class="box-body">
        <table id="example1" class="table table-bordered">
          <thead>
            <th>Date</th><th>Buyer</th><th>Order ID</th><th>Amount</th><th>Status</th><th>Actions</th>
          </thead>
          <tbody>
            <?php
              $conn = $pdo->open();
              try{
                $stmt = $conn->prepare("SELECT *, sales.id AS salesid FROM sales LEFT JOIN users ON users.id=sales.user_id ORDER BY sales_date DESC");
                $stmt->execute();
                foreach($stmt as $row){
                  $stmt_t = $conn->prepare("SELECT SUM(quantity*price) AS total FROM details LEFT JOIN products ON products.id=details.product_id WHERE sales_id=:id");
                  $stmt_t->execute(['id'=>$row['salesid']]);
                  $trow = $stmt_t->fetch();
                  $status = $row['status'] ?? 'Pending';
                  $label = ($status=='Delivered')?'label-success':(($status=='Shipped')?'label-info':(($status=='Cancelled')?'label-danger':'label-warning'));
                  
                  echo "<tr>
                    <td>".date('M d, Y', strtotime($row['sales_date']))."</td>
                    <td>".$row['firstname']." ".$row['lastname']."</td>
                    <td>".$row['pay_id']."</td>
                    <td>KSh ".number_format($trow['total'], 2)."</td>
                    <td><span class='label ".$label."'>".$status."</span></td>
                    <td><button class='btn btn-info btn-sm view btn-flat' data-id='".$row['salesid']."'><i class='fa fa-search'></i> View</button></td>
                  </tr>";
                }
              } catch(PDOException $e){ echo $e->getMessage(); }
              $pdo->close();
            ?>
          </tbody>
        </table>
      </div></div>
    </section>
  </div>
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/orders_modal.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.view', function(e){
    e.preventDefault();
    $('#view_order').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'order_details.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#order_id_input').val(id); 
      $('#customer_name').html(response.name);
      $('#customer_email').html(response.email);
      
      // BUILD PHONE BUTTONS
      var phoneHTML = response.phone;
      if(response.phone !== ''){
          phoneHTML += ' <a href="'+response.contact_link+'" class="btn btn-xs btn-success"><i class="fa fa-phone"></i> Call</a>';
          phoneHTML += ' <a href="'+response.whatsapp_link+'" target="_blank" class="btn btn-xs btn-success" style="background-color:#25D366; border-color:#25D366;"><i class="fa fa-whatsapp"></i> WhatsApp</a>';
      }
      $('#customer_phone').html(phoneHTML);
      
      // BUILD MAP BUTTON
      var mapHTML = response.address;
      if(response.address !== 'No Address Stored'){
          mapHTML += ' <br><a href="'+response.map_link+'" target="_blank" class="btn btn-xs btn-primary" style="margin-top:5px;"><i class="fa fa-map-marker"></i> Open Google Maps</a>';
      }
      $('#customer_address').html(mapHTML);
      
      $('#order_status').val(response.status); 
      $('#detail').html(response.list);
      $('#total').html(response.total);
      $('.transaction').html(response.transaction);
    }
  });
}
</script>
</body>
</html>