<?php
  // This will output a new hash for whatever password you type
  echo password_hash('your_new_password_here', PASSWORD_DEFAULT);
?>