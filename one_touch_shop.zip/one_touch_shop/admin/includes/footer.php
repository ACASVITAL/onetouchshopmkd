<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2026 Brought To You By<a href="#"> ONE TOUCH SHOP</a></strong>
</footer>