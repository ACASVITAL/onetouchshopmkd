<header class="main-header">
  <a href="home.php" class="logo" style="display: flex; align-items: center; justify-content: center;">
    <span class="logo-mini">
      <img src="../images/logo.PNG" alt="Logo" style="width: 30px; height: auto; display: block; margin: 10px auto;">
    </span>
    
    <span class="logo-lg" style="display: flex; align-items: center; justify-content: flex-start;">
      <img src="../images/logo.PNG" alt="Logo" style="height: 35px; width: auto; margin-right: 8px;">
      <span style="font-size: 16px;"><b>One Touch</b> Shop</span>
    </span>
  </a>

  <nav class="navbar navbar-static-top">
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>

    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <?php
              // Define variables with fallbacks
              $admin_photo = (!empty($admin['photo'])) ? '../images/'.$admin['photo'] : '../images/profile.jpg';
              $firstname = $admin['firstname'] ?? 'Admin';
              $lastname = $admin['lastname'] ?? 'User';
            ?>
            <img src="<?php echo $admin_photo; ?>" class="user-image" alt="User Image">
            <span class="hidden-xs"><?php echo $firstname.' '.$lastname; ?></span>
          </a>
          <ul class="dropdown-menu">
            <li class="user-header">
              <img src="<?php echo $admin_photo; ?>" class="img-circle" alt="User Image">
              <p>
                <?php echo $firstname.' '.$lastname; ?>
                <small>Member since <?php echo (isset($admin['created_on'])) ? date('M. Y', strtotime($admin['created_on'])) : date('M. Y'); ?></small>
              </p>
            </li>
            <li class="user-footer">
              <div class="pull-left">
                <a href="#profile" data-toggle="modal" class="btn btn-default btn-flat" id="admin_profile">Update</a>
              </div>
              <div class="pull-right">
                <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>
<?php include 'includes/profile_modal.php'; ?>