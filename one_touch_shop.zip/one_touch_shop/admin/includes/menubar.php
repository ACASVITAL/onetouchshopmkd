<style>
  .main-sidebar { background-color: #3c8dbc !important; }
  .sidebar-menu > li > a { color: #ffffff !important; }
  .sidebar-menu > li.header { background: #367fa9 !important; color: #d1ecf1 !important; }
  .sidebar-menu > li:hover > a, .sidebar-menu > li.active > a { 
    background: #367fa9 !important; color: #ffffff !important; border-left-color: #ffffff !important; 
  }
  .treeview-menu { background: #2c6484 !important; }
</style>

<aside class="main-sidebar">
  <section class="sidebar">
    <div class="user-panel">
      <?php
        // Use ?? (null coalescing) to prevent errors if $admin is not set
        $admin_photo = (!empty($admin['photo'])) ? '../images/'.$admin['photo'] : '../images/profile.jpg';
        $firstname = $admin['firstname'] ?? 'Admin';
        $lastname = $admin['lastname'] ?? 'User';
      ?>
      <div class="pull-left image">
        <img src="<?php echo $admin_photo; ?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p style="color: #fff;"><?php echo $firstname.' '.$lastname; ?></p>
        <a><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>

    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">REPORTS</li>
      <li><a href="home.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
      <li><a href="sales.php"><i class="fa fa-money"></i> <span>Sales History</span></a></li>
      
      <li class="header">MANAGE</li>
      <li><a href="users.php"><i class="fa fa-users"></i> <span>Users</span></a></li>
      
      <li class="treeview">
        <a href="#">
          <i class="fa fa-shopping-cart"></i>
          <span>Orders</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="orders.php"><i class="fa fa-circle-o"></i> View Orders</a></li>
        </ul>
      </li>
      
      <li><a href="complaints.php"><i class="fa fa-envelope"></i> <span>Complaints</span></a></li>
      
      <li class="treeview">
        <a href="#">
          <i class="fa fa-barcode"></i>
          <span>Products</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="products.php"><i class="fa fa-circle-o"></i> Product List</a></li>
          <li><a href="category.php"><i class="fa fa-circle-o"></i> Category</a></li>
        </ul>
      </li>

      <li class="header">NOTIFICATIONS</li>
      <li>
        <a href="sales.php">
          <i class="fa fa-shopping-cart"></i> 
          <span>Pending Sales</span>
          <?php
            // Re-use existing $conn from session.php instead of opening a new one
            $stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM sales WHERE status = 0");
            $stmt->execute();
            $row = $stmt->fetch();
            
            if($row['numrows'] > 0){
              echo "<span class='pull-right-container'>
                      <span class='label label-danger pull-right'>".$row['numrows']."</span>
                    </span>";
            }
            // CRITICAL: REMOVED $pdo->close() from here.
          ?>
        </a>
      </li>
    </ul>
  </section>
</aside>