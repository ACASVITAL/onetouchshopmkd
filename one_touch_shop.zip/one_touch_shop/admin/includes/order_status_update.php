<?php
	include 'includes/session.php';

	if(isset($_POST['update_status'])){
		$id = $_POST['id'];
		$status = $_POST['status'];

		$conn = $pdo->open();
		try{
			// 1. Update Status
			$stmt = $conn->prepare("UPDATE sales SET status=:status WHERE id=:id");
			$stmt->execute(['status'=>$status, 'id'=>$id]);

			// 2. Reduce Inventory if Shipped
			if($status == 'Shipped'){
				$stmt = $conn->prepare("SELECT * FROM details WHERE sales_id=:id");
				$stmt->execute(['id'=>$id]);
				foreach($stmt as $row){
					$stmt_inv = $conn->prepare("UPDATE products SET inventory = inventory - :qty WHERE id=:pid");
					$stmt_inv->execute(['qty'=>$row['quantity'], 'pid'=>$row['product_id']]);
				}
			}

			// 3. Email Buyer
			$stmt = $conn->prepare("SELECT * FROM sales LEFT JOIN users ON users.id=sales.user_id WHERE sales.id=:id");
			$stmt->execute(['id'=>$id]);
			$user = $stmt->fetch();

			$subject = "Order #".$user['pay_id']." Update";
			$msg = "Hello ".$user['firstname'].", your order is now: ".$status;
			$headers = "From: support@yourstore.com\r\nContent-type:text/html";
			mail($user['email'], $subject, $msg, $headers);

			// 4. Check for Low Stock Alerts
			$stmt_alert = $conn->prepare("SELECT name FROM products WHERE inventory <= 5");
			$stmt_alert->execute();
			$low = $stmt_alert->fetchAll(PDO::FETCH_COLUMN);
			
			if($low){
				$_SESSION['success'] = 'Updated. WARNING: Low stock on: '.implode(', ', $low);
			} else {
				$_SESSION['success'] = 'Order status updated.';
			}
		}
		catch(PDOException $e){ $_SESSION['error'] = $e->getMessage(); }
		$pdo->close();
	}
	header('location: orders.php');
?>