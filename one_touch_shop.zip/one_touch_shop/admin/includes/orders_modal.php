<div class="modal fade" id="view_order">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form class="form-horizontal" method="POST" action="order_status_update.php">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title"><b>Order Details & Delivery Manager</b></h4>
                </div>
                <div class="modal-body">
                  <input type="hidden" id="order_id_input" name="id">
                  
                  <div class="row">
                    <div class="col-md-6">
                      <p><strong>Customer:</strong> <span id="customer_name"></span></p>
                      <p><strong>Email:</strong> <span id="customer_email"></span></p>
                      <p><strong>Phone:</strong> <span id="customer_phone"></span></p>
                      <p><strong>Location:</strong> <span id="customer_address"></span></p>
                    </div>

                    <div class="col-md-6" style="border-left: 1px solid #eee;">
                      <div class="form-group">
                        <label class="col-sm-4 control-label">Update Status</label>
                        <div class="col-sm-8">
                          <select class="form-control" name="status" id="order_status">
                            <option value="Pending">Pending</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>
                      <p class="pull-right"><strong>Transaction ID:</strong> <span class="transaction"></span></p>
                    </div>
                  </div>

                  <hr>

                  <table class="table table-bordered">
                    <thead>
                      <th style="background:#f4f4f4">Product</th>
                      <th style="background:#f4f4f4">Price</th>
                      <th style="background:#f4f4f4">Qty</th>
                      <th style="background:#f4f4f4">Subtotal</th>
                    </thead>
                    <tbody id="detail"></tbody>
                    <tfoot>
                      <tr>
                        <td colspan="3" align="right"><b>Total</b></td>
                        <td><span id="total"></span></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-success btn-flat" name="update_status"><i class="fa fa-save"></i> Update Order & Notify Buyer</button>
                </div>
            </form>
        </div>
    </div>
</div>