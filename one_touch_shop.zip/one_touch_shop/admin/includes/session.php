<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ob_start();

    // This finds the path regardless of where the file is called from
    $conn_file = __DIR__ . '/../../includes/conn.php';

    if(file_exists($conn_file)){
        include_once($conn_file);
    } else {
        die("System Error: Cannot find conn.php at " . $conn_file);
    }

    if(session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if(!isset($_SESSION['admin']) || trim($_SESSION['admin']) == ''){
        header('location: login.php');
        exit();
    }

    $conn = $pdo->open();
    // Fetch admin details...
?>