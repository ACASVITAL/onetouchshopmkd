<?php
    include '../includes/conn.php';
    session_start();

    $conn = $pdo->open();

    if(isset($_POST['login'])){
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        try{
            $stmt = $conn->prepare("SELECT *, COUNT(*) AS numrows FROM users WHERE email = :email");
            $stmt->execute(['email'=>$email]);
            $row = $stmt->fetch();

            if($row['numrows'] > 0){
                // 1. Check if User is Admin
                if($row['type'] == 1){
                    // 2. Verify Password (Hashed or Plain Text fallback)
                    if(password_verify($password, $row['password']) || $password === $row['password']){
                        
                        // Set Session
                        $_SESSION['admin'] = $row['id'];
                        
                        $pdo->close();
                        header('location: home.php');
                        exit();
                    }
                    else{
                        $_SESSION['error'] = 'Incorrect password.';
                    }
                }
                else{
                    $_SESSION['error'] = 'Access denied. Account is not an admin.';
                }
            }
            else{
                $_SESSION['error'] = 'Email not found.';
            }
        }
        catch(PDOException $e){
            $_SESSION['error'] = "Database Error: " . $e->getMessage();
        }
    }
    else{
        $_SESSION['error'] = 'Please input login credentials.';
    }

    $pdo->close();
    header('location: login.php');
    exit();
?>