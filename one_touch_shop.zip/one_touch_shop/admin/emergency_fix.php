<?php
include '../includes/conn.php';
$conn = $pdo->open();

$email = 'brianmwololo@gmail.com';
$new_password = 'admin123';

// This creates a fresh, valid hash
$hashed = password_hash($new_password, PASSWORD_DEFAULT);

try {
    $stmt = $conn->prepare("UPDATE users SET password = :pass WHERE email = :email");
    $stmt->execute(['pass'=>$hashed, 'email'=>$email]);
    
    if($stmt->rowCount() > 0){
        echo "<h2>Success!</h2>";
        echo "The password for <b>$email</b> has been reset to <b>$new_password</b>.<br>";
        echo "The new hash generated was: <code>$hashed</code><br>";
        echo "<a href='login.php'>Try Logging In Now</a>";
    } else {
        echo "<h2>Error</h2>";
        echo "Could not find an account with that email to update.";
    }
} catch(PDOException $e) {
    echo "DB Error: " . $e->getMessage();
}

$pdo->close();
?>