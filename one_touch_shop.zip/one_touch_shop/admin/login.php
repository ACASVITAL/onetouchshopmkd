<?php session_start(); ?>
<?php 
  // If already logged in, skip login page and go to home
  if(isset($_SESSION['admin'])){
    header('location: home.php');
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login | eCommerce</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <?php
                if(isset($_SESSION['error'])){
                    echo "<div class='alert alert-danger text-center'>".$_SESSION['error']."</div>";
                    unset($_SESSION['error']);
                }
                if(isset($_SESSION['success'])){
                    echo "<div class='alert alert-success text-center'>".$_SESSION['success']."</div>";
                    unset($_SESSION['success']);
                }
            ?>
            <div class="card shadow border-0">
                <div class="card-body">
                    <h4 class="text-center mb-4">Admin Access</h4>
                    <form action="verify.php" method="POST">
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" class="form-control" required autofocus>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-primary btn-block">Sign In</button>
                    </form>
                    <hr>
                    <div class="text-center">
                        <a href="../index.php" class="small">Back to Website</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>