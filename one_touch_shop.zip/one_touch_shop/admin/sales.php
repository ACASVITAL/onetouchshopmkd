<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>Sales History</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Sales</li>
      </ol>
    </section>

    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <div class="pull-right">
                <form method="POST" class="form-inline" action="sales_print.php">
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" class="form-control pull-right col-sm-8" id="reservation" name="date_range">
                  </div>
                  <button type="submit" class="btn btn-success btn-sm btn-flat" name="print"><span class="glyphicon glyphicon-print"></span> Print Report</button>
                </form>
              </div>
            </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <th class="hidden"></th>
                  <th>Date</th>
                  <th>Buyer Name</th>
                  <th>Transaction ID</th>
                  <th>Amount (KSh)</th>
                  <th>Status</th>
                  <th>Action</th>
                </thead>
                <tbody>
                  <?php
                    $conn = $pdo->open();

                    try{
                      $stmt = $conn->prepare("SELECT *, sales.id AS salesid, sales.status AS sales_status FROM sales LEFT JOIN users ON users.id=sales.user_id ORDER BY sales_date DESC");
                      $stmt->execute();
                      
                      foreach($stmt as $row){
                        $stmt_details = $conn->prepare("SELECT * FROM details LEFT JOIN products ON products.id=details.product_id WHERE details.sales_id=:id");
                        $stmt_details->execute(['id'=>$row['salesid']]);
                        $total = 0;
                        foreach($stmt_details as $details){
                          $subtotal = $details['price'] * $details['quantity'];
                          $total += $subtotal;
                        }

                        $status_val = (int)$row['sales_status']; 
                        switch($status_val){
                            case 1:
                                $status_label = "<span class='label label-info'><i class='fa fa-ship'></i> SHIPPED</span>";
                                break;
                            case 2:
                                $status_label = "<span class='label label-success'><i class='fa fa-check-circle'></i> DELIVERED</span>";
                                break;
                            case 3:
                                $status_label = "<span class='label label-danger'><i class='fa fa-times-circle'></i> CANCELLED</span>";
                                break;
                            default:
                                $status_label = "<span class='label label-warning'><i class='fa fa-clock-o'></i> PENDING</span>";
                                break;
                        }

                        echo "
                          <tr>
                            <td class='hidden'></td>
                            <td>".date('M d, Y', strtotime($row['sales_date']))."</td>
                            <td>".$row['firstname'].' '.$row['lastname']."</td>
                            <td>".$row['pay_id']."</td>
                            <td style='font-weight:bold;'>KSh ".number_format($total, 2)."</td>
                            <td>".$status_label."</td>
                            <td>
                              <button type='button' class='btn btn-info btn-xs btn-flat transact' data-id='".$row['salesid']."'><i class='fa fa-search'></i> View</button>
                              <button type='button' class='btn btn-primary btn-xs btn-flat edit_status' data-id='".$row['salesid']."' data-status='".$status_val."'><i class='fa fa-edit'></i> Status</button>
                              <button type='button' class='btn btn-danger btn-xs btn-flat delete_sales' data-id='".$row['salesid']."'><i class='fa fa-trash'></i> Delete</button>
                            </td>
                          </tr>
                        ";
                      }
                    }
                    catch(PDOException $e){
                      echo "Error: " . $e->getMessage();
                    }

                    $pdo->close();
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <div class="modal fade" id="modal_status">
      <div class="modal-dialog">
          <div class="modal-content">
              <form method="POST" action="sales_status.php">
                <input type="hidden" class="sales_id" name="id">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"><b>Manage Order Status</b></h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Transaction ID:</label>
                        <input type="text" class="form-control" id="display_id" readonly style="background:#f9f9f9;">
                    </div>
                    <div class="form-group">
                        <label>Select Current Progress:</label>
                        <select class="form-control" name="status" id="status_select">
                            <option value="0">Pending (Awaiting fulfillment)</option>
                            <option value="1">Shipped (In transit)</option>
                            <option value="2">Delivered (Completed)</option>
                            <option value="3">Cancelled (Voided)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary btn-flat" name="update_status"><i class="fa fa-save"></i> Save Changes</button>
                </div>
              </form>
          </div>
      </div>
  </div>

  <div class="modal fade" id="delete_sales_modal">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><b>Deleting Sale Record...</b></h4>
              </div>
              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="sales_delete.php">
                  <input type="hidden" class="sales_id" name="id">
                  <div class="text-center">
                      <p>DELETE SALES HISTORY</p>
                      <h2 class="bold">Are you sure you want to delete this record?</h2>
                      <p class="text-danger">Note: This action cannot be undone and will affect sales reports.</p>
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-danger btn-flat" name="delete"><i class="fa fa-trash"></i> Delete</button>
                </form>
              </div>
          </div>
      </div>
  </div>

  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/sales_modal.php'; ?> 
</div>

<?php include 'includes/scripts.php'; ?>

<script>
$(function(){
  $('#reservation').daterangepicker();

  $(document).on('click', '.transact', function(e){
    e.preventDefault();
    $('#transaction').modal('show');
    var id = $(this).data('id');
    $.ajax({
      type: 'POST',
      url: 'transact.php',
      data: {id:id},
      dataType: 'json',
      success:function(response){
        $('#date').html(response.date);
        $('#transid').html(response.transaction);
        $('#detail').prepend(response.list);
        $('#total').html(response.total);
      }
    });
  });

  $(document).on('click', '.edit_status', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    var status = $(this).data('status');
    $('.sales_id').val(id);
    $('#display_id').val(id);
    $('#status_select').val(status);
    $('#modal_status').modal('show');
  });

  $(document).on('click', '.delete_sales', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    $('.sales_id').val(id);
    $('#delete_sales_modal').modal('show');
  });

  $("#transaction").on("hidden.bs.modal", function () {
      $('.prepend_items').remove();
  });
});
</script>
</body>
</html>