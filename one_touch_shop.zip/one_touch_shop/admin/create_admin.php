<?php
    include '../includes/conn.php';

    $conn = $pdo->open();

    // Set your desired credentials here
    $email = 'brianmwololo89@gmail.com';
    $password = 'admin123'; // The plain text password
    $firstname = 'System';
    $lastname = 'Admin';
    
    // Hash the password for the database
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO users (email, password, firstname, lastname, type, status, created_on) VALUES (:email, :password, :firstname, :lastname, :type, :status, :created_on)");
        $stmt->execute([
            'email' => $email,
            'password' => $hashed_password,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'type' => 1, // 1 usually denotes Admin
            'status' => 1,
            'created_on' => date('Y-m-d')
        ]);

        echo "Admin account created successfully! You can now login with: <br>";
        echo "Email: " . $email . "<br>Password: " . $password;
    }
    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $pdo->close();
?>