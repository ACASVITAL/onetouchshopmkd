<?php
	include 'includes/session.php';

	if(isset($_POST['reply'])){
		$id = $_POST['id'];
		$reply = $_POST['admin_reply'];

		$conn = $pdo->open();

		try{
			// Update the complaint with the admin's response and set status to 1
			$stmt = $conn->prepare("UPDATE complaints SET admin_reply=:reply, status=:status WHERE id=:id");
			$stmt->execute(['reply'=>$reply, 'status'=>1, 'id'=>$id]);

			$_SESSION['success'] = 'Reply sent successfully to the buyer';
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Please fill up the reply form first';
	}

	// Redirect back to the complaints list
	header('location: complaints.php');
?>