<?php
	include 'includes/session.php';

	if(isset($_POST['update_status'])){
		$id = $_POST['id'];
		$status = $_POST['status'];

		$conn = $pdo->open();

		try{
			// Update the status based on the selection from the modal
			$stmt = $conn->prepare("UPDATE sales SET status=:status WHERE id=:id");
			$stmt->execute(['status'=>$status, 'id'=>$id]);
			
			$_SESSION['success'] = 'Order status updated successfully';
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Fill up the status update form first';
	}

	// Redirect back to the main sales page
	header('location: sales.php');
?>