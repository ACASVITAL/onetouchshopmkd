<?php
	include 'includes/session.php';

	if(isset($_POST['update_status'])){
		$id = $_POST['id'];
		$status = $_POST['status'];

		$conn = $pdo->open();
		try{
			$stmt = $conn->prepare("UPDATE sales SET status=:status WHERE id=:id");
			$stmt->execute(['status'=>$status, 'id'=>$id]);
			$_SESSION['success'] = 'Order status updated successfully';
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
	}

	header('location: orders.php');
?>