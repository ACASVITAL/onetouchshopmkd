<?php
// 1. Force the server to show errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>System Debugger Started...</h3>";
echo "<hr>";

// TEST 1: Check File Existence
echo "<b>Test 1: Checking includes folder...</b><br>";
if (is_dir('includes')) {
    echo "<span style='color:green'>✔ 'includes' folder found.</span><br>";
} else {
    die("<span style='color:red'>✘ FAIL: 'includes' folder not found. Check your folder structure!</span>");
}

// TEST 2: Check session.php
echo "<br><b>Test 2: Attempting to include session.php...</b><br>";
if (file_exists('includes/session.php')) {
    include 'includes/session.php';
    echo "<span style='color:green'>✔ session.php included.</span><br>";
} else {
    die("<span style='color:red'>✘ FAIL: includes/session.php is missing!</span>");
}

// TEST 3: Check Database Object
echo "<br><b>Test 3: Checking Database Object (\$pdo)...</b><br>";
if (isset($pdo)) {
    echo "<span style='color:green'>✔ \$pdo object exists.</span><br>";
} else {
    die("<span style='color:red'>✘ FAIL: \$pdo object was not created. Check your conn.php syntax!</span>");
}

// TEST 4: Check Database Connection
echo "<br><b>Test 4: Attempting to Open Database...</b><br>";
try {
    $conn = $pdo->open();
    if ($conn) {
        echo "<span style='color:green'>✔ Database Connection Successful!</span><br>";
    }
} catch (Exception $e) {
    die("<span style='color:red'>✘ FAIL: Connection error: " . $e->getMessage() . "</span>");
}

// TEST 5: Check Admin Data
echo "<br><b>Test 5: Checking Logged-in Admin...</b><br>";
if (isset($admin)) {
    echo "<span style='color:green'>✔ Admin data found for: " . $admin['firstname'] . " " . $admin['lastname'] . "</span><br>";
} else {
    echo "<span style='color:orange'>⚠ WARNING: No admin session found. You are likely logged out.</span><br>";
}

echo "<hr>";
echo "<h3 style='color:blue'>Diagnostics Complete! If you see this, your core files are working.</h3>";
?>