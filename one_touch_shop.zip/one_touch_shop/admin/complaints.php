<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    <?php include 'includes/menubar.php'; ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1>Customer Complaints</h1>
        </section>

        <section class="content">
            <?php
                if(isset($_SESSION['error'])){
                  echo "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><h4><i class='icon fa fa-warning'></i> Error!</h4>".$_SESSION['error']."</div>";
                  unset($_SESSION['error']);
                }
                if(isset($_SESSION['success'])){
                  echo "<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><h4><i class='icon fa fa-check'></i> Success!</h4>".$_SESSION['success']."</div>";
                  unset($_SESSION['success']);
                }
            ?>
            <div class="box box-solid">
                <div class="box-body">
                    <table class="table table-bordered" id="example1">
                        <thead>
                            <th>Date</th>
                            <th>Customer Name</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php
                                $conn = $pdo->open();
                                try{
                                    $stmt = $conn->prepare("SELECT complaints.*, users.firstname, users.lastname FROM complaints JOIN users ON users.id=complaints.user_id ORDER BY created_on DESC");
                                    $stmt->execute();
                                    foreach($stmt as $row){
                                        $status = ($row['status']) ? '<span class="label label-success">Replied</span>' : '<span class="label label-danger">Pending</span>';
                                        echo "
                                            <tr>
                                                <td>".date('M d, Y', strtotime($row['created_on']))."</td>
                                                <td>".$row['firstname']." ".$row['lastname']."</td>
                                                <td>".$row['subject']."</td>
                                                <td>".$status."</td>
                                                <td><button class='btn btn-info btn-sm view btn-flat' data-id='".$row['id']."'><i class='fa fa-reply'></i> View & Reply</button></td>
                                            </tr>
                                        ";
                                    }
                                } catch(PDOException $e){ echo $e->getMessage(); }
                                $pdo->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
    <?php include 'includes/footer.php'; ?>

    <div class="modal fade" id="view">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title"><b>Complaint Details</b></h4>
                </div>
                <form action="complaints_reply.php" method="POST">
                    <input type="hidden" class="complaint_id" name="id">
                    <div class="modal-body">
                        <p><strong>Customer:</strong> <span class="name"></span></p>
                        <p><strong>Subject:</strong> <span class="subject"></span></p>
                        <hr>
                        <p><strong>Buyer Message:</strong></p>
                        <div class="well"><p class="message"></p></div>
                        <div class="form-group">
                            <label>Admin Reply:</label>
                            <textarea name="admin_reply" class="form-control" rows="5" id="admin_reply" placeholder="Write your response here..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary btn-flat" name="reply">Send Reply</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.view', function(e){
    e.preventDefault();
    $('#view').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });
});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'complaints_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('.complaint_id').val(response.id);
      $('.name').html(response.firstname+' '+response.lastname);
      $('.subject').html(response.subject);
      $('.message').html(response.message);
      $('#admin_reply').val(response.admin_reply); // Load existing reply if any
    }
  });
}
</script>
</body>