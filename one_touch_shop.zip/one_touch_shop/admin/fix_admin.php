<?php
    include '../includes/conn.php';
    $conn = $pdo->open();

    try {
        // 1. Fix column length just in case
        $conn->exec("ALTER TABLE users MODIFY COLUMN password VARCHAR(255) NOT NULL");

        // 2. Hash the password 'admin123'
        $password = 'admin123';
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        // 3. Update or Insert the admin user
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => 'admin@admin.com']);
        
        if($stmt->rowCount() > 0){
            $stmt = $conn->prepare("UPDATE users SET password = :pass, type = 1 WHERE email = :email");
            $stmt->execute(['pass' => $hashed, 'email' => 'admin@admin.com']);
            echo "Admin password updated successfully!";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (email, password, type, firstname, lastname, created_on) VALUES (:email, :pass, 1, 'Admin', 'User', NOW())");
            $stmt->execute(['email' => 'admin@admin.com', 'pass' => $hashed]);
            echo "Admin user created successfully!";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $pdo->close();
?>