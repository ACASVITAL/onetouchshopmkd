<?php
	include 'includes/session.php';

	if(isset($_POST['upload'])){
		$id = $_POST['id'];
		$filename = $_FILES['photo']['name'];

		$conn = $pdo->open();

		// 1. Fetch current product data to get the slug and the OLD photo name
		$stmt = $conn->prepare("SELECT * FROM products WHERE id=:id");
		$stmt->execute(['id'=>$id]);
		$row = $stmt->fetch();

		if(!empty($filename)){
			// 2. Delete the OLD photo from the folder if it exists
			if(!empty($row['photo']) && file_exists('../images/'.$row['photo'])){
				unlink('../images/'.$row['photo']);
			}

			// 3. Prepare the NEW photo name
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			$new_filename = $row['slug'].'_'.time().'.'.$ext; // Added time() to prevent browser caching issues
			
			// 4. Move the file
			if(move_uploaded_file($_FILES['photo']['tmp_name'], '../images/'.$new_filename)){
				try{
					$stmt = $conn->prepare("UPDATE products SET photo=:photo WHERE id=:id");
					$stmt->execute(['photo'=>$new_filename, 'id'=>$id]);
					$_SESSION['success'] = 'Product photo updated successfully';
				}
				catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
				}
			}
			else{
				$_SESSION['error'] = 'Failed to upload photo. Check folder permissions.';
			}
		}
		else{
			$_SESSION['error'] = 'Please select a new photo first';
		}

		$pdo->close();

	}
	else{
		$_SESSION['error'] = 'Select product to update photo first';
	}

	header('location: products.php');
?>