<?php
	include 'includes/session.php';

	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		
		$conn = $pdo->open();

		try{
			/**
			 * We delete from the 'details' table first because it has a 
			 * foreign key relationship with the 'sales' table.
			 */
			$stmt = $conn->prepare("DELETE FROM details WHERE sales_id=:id");
			$stmt->execute(['id'=>$id]);

			// Now delete the main sale record
			$stmt = $conn->prepare("DELETE FROM sales WHERE id=:id");
			$stmt->execute(['id'=>$id]);

			$_SESSION['success'] = 'Sales history record deleted successfully';
		}
		catch(PDOException $e){
			$_SESSION['error'] = 'Something went wrong: ' . $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Select a record to delete first';
	}

	// Redirect back to your updated sales.php
	header('location: sales.php');
?>