<?php
	include 'includes/session.php';

	if(isset($_POST['cancel'])){
		$id = $_POST['id'];
		
		$conn = $pdo->open();
		try{
			// status 3 = Cancelled
			$stmt = $conn->prepare("UPDATE sales SET status=:status WHERE id=:id AND user_id=:user_id AND status=:pending_status");
			$stmt->execute(['status'=>3, 'id'=>$id, 'user_id'=>$user['id'], 'pending_status'=>0]);
			
			if($stmt->rowCount() > 0){
				$_SESSION['success'] = 'Order cancelled successfully';
			} else {
				$_SESSION['error'] = 'Order could not be cancelled. It might have already been shipped.';
			}
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Select order to cancel first';
	}

	header('location: sales_history.php');
?>