<?php
	include 'includes/session.php';

	if(isset($_POST['direct_reset'])){
		$email = $_POST['email'];
		$password = $_POST['password'];
		$repassword = $_POST['repassword'];

		if($password != $repassword){
			$_SESSION['error'] = 'Passwords do not match';
		}
		else{
			$conn = $pdo->open();

			// 1. Check if the email exists
			$stmt = $conn->prepare("SELECT *, COUNT(*) AS numrows FROM users WHERE email=:email");
			$stmt->execute(['email'=>$email]);
			$row = $stmt->fetch();

			if($row['numrows'] > 0){
				// 2. Hash the new password
				$new_password = password_hash($password, PASSWORD_DEFAULT);

				try{
					// 3. Update the password
					$stmt = $conn->prepare("UPDATE users SET password=:password WHERE id=:id");
					$stmt->execute(['password'=>$new_password, 'id'=>$row['id']]);
					
					$_SESSION['success'] = 'Password updated successfully. You can now login.';
					header('location: login.php');
					exit();
				}
				catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
				}
			}
			else{
				$_SESSION['error'] = 'Email not found in our records.';
			}

			$pdo->close();
		}
	}
	else{
		$_SESSION['error'] = 'Please fill up the form first';
	}

	header('location: password_forgot.php');
?>