<div class="row">
    <div class="box box-solid" style="border-radius: 10px; border-top: 3px solid #3c8dbc;">
        <div class="box-header with-border">
            <h3 class="box-title"><b>Most Viewed Today</b></h3>
        </div>
        <div class="box-body">
            <ul id="trending" style="list-style: none; padding-left: 0;">
            <?php
                // We use unique variables here ($side_now, $side_stmt) 
                // to prevent overwriting variables on the main category page.
                $side_now = date('Y-m-d');
                $conn = $pdo->open();

                try {
                    $side_stmt = $conn->prepare("SELECT * FROM products WHERE date_view=:now ORDER BY counter DESC LIMIT 10");
                    $side_stmt->execute(['now' => $side_now]);
                    
                    if($side_stmt->rowCount() > 0) {
                        foreach($side_stmt as $side_row) {
                            echo "
                                <li style='padding: 5px 0; border-bottom: 1px solid #f4f4f4;'>
                                    <i class='fa fa-caret-right' style='color: #3c8dbc;'></i> 
                                    <a href='product.php?product=".$side_row['slug']."' style='color: #444; margin-left: 5px;'>".$side_row['name']."</a>
                                </li>
                            ";
                        }
                    } else {
                        echo "<li class='text-muted'>No trending products today.</li>";
                    }
                } catch (PDOException $e) {
                    echo "Error: " . $e->getMessage();
                }

                $pdo->close();
            ?>
            </ul>
        </div>
    </div>
</div>

