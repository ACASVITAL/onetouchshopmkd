<header class="main-header">
  <nav class="navbar navbar-static-top" style="background-color: #3c8dbc; border: none;">
    <div class="container">
      <div class="navbar-header">
        <a href="index.php" class="navbar-brand" style="color: white; font-weight: bold; display: flex; align-items: center; padding: 5px 15px;">
          <img src="images/logo.PNG" alt="Logo" style="height: 40px; width: auto; margin-right: 10px;">
          <span><b>One Touch </b>Shop</span>
        </a>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" style="border-color: white;">
          <i class="fa fa-bars" style="color: white;"></i>
        </button>
      </div>

      <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php" style="color: white;">HOME</a></li>
          
          <li><a href="sales_history.php" style="color: white;"><i class="fa fa-truck"></i> TRACK PRODUCT</a></li>
          
          <li>
            <a href="https://wa.me/254790723820?text=Hello%20One%20Touch%20Shop,%20I%20have%20an%20enquiry." 
               target="_blank" 
               style="color: white;">
               <i class="fa fa-whatsapp"></i> CONTACT US
            </a>
          </li>

          <li><a href="complaints_view.php" style="color: white;">COMPLAINTS</a></li>

        
            <ul class="dropdown-menu" role="menu">
              <?php
                $conn = $pdo->open();
                try {
                  $stmt = $conn->prepare("SELECT c.*, COUNT(p.id) AS p_count 
                                          FROM category c 
                                          LEFT JOIN products p ON c.id = p.category_id 
                                          GROUP BY c.id");
                  $stmt->execute();
                  foreach($stmt as $row) {
                    echo "
                      <li>
                        <a href='category.php?category=".$row['cat_slug']."'>
                          ".$row['name']." 
                          <span class='label label-default pull-right' style='margin-left:10px;'>".$row['p_count']."</span>
                        </a>
                      </li>
                    ";                  
                  }
                }
                catch(PDOException $e) {
                  echo "<li><a>Error loading categories</a></li>";
                }
                $pdo->close();
              ?>
            </ul>
          </li>
        </ul>

        <form method="POST" class="navbar-form navbar-left" action="search.php">
          <div class="input-group">
              <input type="text" class="form-control" id="navbar-search-input" name="keyword" placeholder="Search for Product" required style="border-radius: 20px 0 0 20px; border: none;">
              <span class="input-group-btn">
                  <button type="submit" class="btn btn-default btn-flat" style="border-radius: 0 20px 20px 0; border: none; background: #eee;">
                    <i class="fa fa-search"></i>
                  </button>
              </span>
          </div>
        </form>
      </div>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white;">
              <i class="fa fa-shopping-cart"></i>
              <span class="label label-success cart_count"></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have <span class="cart_count"></span> item(s) in cart</li>
              <li>
                <ul class="menu" id="cart_menu"></ul>
              </li>
              <li class="footer"><a href="cart_view.php">Go to Cart</a></li>
            </ul>
          </li>
          
          <?php
            if(isset($_SESSION['user'])){
              $conn = $pdo->open();
              $stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
              $stmt->execute(['id'=>$_SESSION['user']]);
              $user = $stmt->fetch();
              $pdo->close();

              $image = (!empty($user['photo'])) ? 'images/'.$user['photo'] : 'images/profile.jpg';
              echo '
                <li class="dropdown user user-menu">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: white;">
                    <img src="'.$image.'" class="user-image" alt="User Image">
                    <span class="hidden-xs">'.$user['firstname'].' '.$user['lastname'].'</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li class="user-header" style="background-color: #3c8dbc; border: none;">
                      <img src="'.$image.'" class="img-circle" alt="User Image">
                      <p style="color: white;">
                        '.$user['firstname'].' '.$user['lastname'].'
                        <small>Member since '.date('M. Y', strtotime($user['created_on'])).'</small>
                      </p>
                    </li>
                    <li class="user-footer">
                      <div class="pull-left">
                        <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                      </div>
                      <div class="pull-right">
                        <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                      </div>
                    </li>
                  </ul>
                </li>
              ';
            }
            else{
              echo "
                <li><a href='login.php' style='color: white;'>LOGIN</a></li>
                <li><a href='signup.php' style='color: white;'>SIGNUP</a></li>
              ";
            }
          ?>
        </ul>
      </div>
    </div>
  </nav>
</header>

<style>
  .navbar-nav > li > a:hover, .navbar-nav > li > a:focus {
    background-color: rgba(0,0,0,0.1) !important;
    color: #fff !important;
  }
  .dropdown-menu > li > a {
    color: #333 !important;
    padding: 10px 20px;
  }
  .dropdown-menu > li > a:hover {
    background-color: #f4f4f4 !important;
  }
  #navbar-search-input:focus {
    box-shadow: none;
    border: 1px solid #3c8dbc;
  }
  .navbar-brand img {
    display: inline-block;
  }
</style>