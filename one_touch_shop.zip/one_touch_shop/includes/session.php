<?php
	include 'includes/conn.php';
	session_start();

	// 1. Redirect Admin ONLY if they are trying to access the public store front
	// This check prevents the loop by identifying if we are already in the admin folder
	if(isset($_SESSION['admin'])){
		if (strpos($_SERVER['PHP_SELF'], 'admin/') === false) {
			header('location: admin/home.php');
			exit(); // Always use exit() after a header redirect
		}
	}

	// 2. Fetch User Data if logged in
	if(isset($_SESSION['user'])){
		$conn = $pdo->open();

		try{
			$stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
			$stmt->execute(['id'=>$_SESSION['user']]);
			$user = $stmt->fetch();
		}
		catch(PDOException $e){
			echo "There is some problem in connection: " . $e->getMessage();
		}

		$pdo->close();
	}
?>