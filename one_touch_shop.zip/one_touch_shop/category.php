<?php include 'includes/session.php'; ?>
<?php
    $slug = $_GET['category'];
    $conn = $pdo->open();

    try{
        $stmt = $conn->prepare("SELECT * FROM category WHERE cat_slug = :slug");
        $stmt->execute(['slug' => $slug]);
        $current_category = $stmt->fetch(); 
        
        if($current_category){
            $catid = $current_category['id'];
        } else {
            header('location: index.php');
            exit();
        }
    }
    catch(PDOException $e){
        echo "There is some problem in connection: " . $e->getMessage();
    }
    
    $pdo->close(); 
?>
<?php include 'includes/header.php'; ?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<style>
    .prod-body { height: 320px; padding: 15px; display: flex; flex-direction: column; justify-content: space-between; }
    .search-input { border-radius: 20px; border: 2px solid #3c8dbc; padding-left: 20px; height: 45px; }
    .page-header { border-bottom: 3px solid #3c8dbc; font-weight: bold; padding-bottom: 10px; }
    .thumbnail { transition: all .3s ease; border: 1px solid #eee; width: 100%; height: 200px; object-fit: contain; }
    .thumbnail:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
    
    #backToTop {
        position: fixed; bottom: 30px; right: 30px; z-index: 99;
        display: none; background-color: #3c8dbc; color: white;
        width: 50px; height: 50px; border-radius: 50%; border: none;
        cursor: pointer; box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }
</style>

<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

    <?php include 'includes/navbar.php'; ?>
     
     <div class="content-wrapper">
        <div class="container">
          <section class="content">
            <div class="row">
                <div class="col-sm-9">
                    <h1 class="page-header"><i class="fa fa-tags"></i> <?php echo $current_category['name']; ?></h1>

                    <div class="row" style="margin-bottom: 25px;">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon" style="background: #3c8dbc; color: white; border-radius: 20px 0 0 20px;"><i class="fa fa-search"></i></span>
                                <input type="text" id="product_search" class="form-control search-input" placeholder="Search in this category...">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="box box-solid" style="border: 1px solid #3c8dbc; border-radius: 15px;">
                                <div class="box-body">
                                    <label style="color: #3c8dbc;"><i class="fa fa-money"></i> Price Filter:</label>
                                    <input type="text" id="amount" readonly style="border:0; color:#f56954; font-weight:bold; background: transparent; width: 100%;">
                                    <div id="price-range" style="margin: 10px 5px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="no-results" style="display:none; padding: 50px 0;" class="text-center">
                        <i class="fa fa-shopping-basket fa-4x text-muted"></i>
                        <h3 class="text-muted">Oops! No products found matching your search.</h3>
                        <button class="btn btn-primary btn-lg btn-flat" onclick="resetFilters()">Reset All Filters</button>
                    </div>

                    <div id="product_list">
                    <?php
                        $conn = $pdo->open();
                        try{
                            $inc = 3;   
                            $prod_stmt = $conn->prepare("SELECT * FROM products WHERE category_id = :catid ORDER BY id DESC");
                            $prod_stmt->execute(['catid' => $catid]);
                            $rows = $prod_stmt->fetchAll(); 
                            
                            if(count($rows) > 0){
                                foreach ($rows as $row) {
                                    $image = (!empty($row['photo'])) ? 'images/'.$row['photo'] : 'images/noimage.jpg';
                                    $inc = ($inc == 3) ? 1 : $inc + 1;
                                    if($inc == 1) echo "<div class='row'>";
                                    ?>
                                        <div class='col-sm-4 item-container' data-price='<?php echo $row['price']; ?>'>
                                            <div class='box box-solid' style='border-radius:10px; overflow:hidden;'>
                                                <div class='box-body prod-body text-center'>
                                                    <img src='<?php echo $image; ?>' class='thumbnail'>
                                                    <h5 class='product-name-text' style='font-weight:bold; margin-top:15px;'>
                                                        <a href='product.php?product=<?php echo $row['slug']; ?>'><?php echo $row['name']; ?></a>
                                                    </h5>
                                                </div>
                                                <div class='box-footer' style='background:#fcfcfc;'>
                                                    <span style='font-size:18px; color:#3c8dbc; font-weight:bold;'>KSh <?php echo number_format($row['price'], 2); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    if($inc == 3) echo "</div>";
                                }
                                if($inc == 1 || $inc == 2) echo "</div>"; 
                            } else {
                                echo "<div class='alert alert-info'>This category is currently empty.</div>";
                            }
                        }
                        catch(PDOException $e){ echo $e->getMessage(); }
                        $pdo->close();
                    ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <?php include 'includes/sidebar.php'; ?>
                </div>
            </div>
          </section>
        </div>
      </div>
  
    <?php include 'includes/footer.php'; ?>
    <button id="backToTop" title="Go to top"><i class="fa fa-chevron-up"></i></button>
</div>

<?php include 'includes/scripts.php'; ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
$(function() {
    // 1. Initialize Slider
    $("#price-range").slider({
        range: true,
        min: 0,
        max: 500000, 
        values: [0, 500000],
        slide: function(event, ui) {
            $("#amount").val("KSh " + ui.values[0].toLocaleString() + " - KSh " + ui.values[1].toLocaleString());
            applyFilters();
        }
    });
    
    $("#amount").val("KSh " + $("#price-range").slider("values", 0).toLocaleString() + " - KSh " + $("#price-range").slider("values", 1).toLocaleString());

    // 2. Search Trigger
    $("#product_search").on("keyup", function() {
        applyFilters();
    });

    // 3. Scroll logic
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) { $('#backToTop').fadeIn(); } 
        else { $('#backToTop').fadeOut(); }
    });
    $('#backToTop').click(function() {
        $('html, body').animate({scrollTop : 0}, 800);
        return false;
    });
});

function applyFilters() {
    var searchText = $("#product_search").val().toLowerCase();
    var minPrice = $("#price-range").slider("values", 0);
    var maxPrice = $("#price-range").slider("values", 1);
    var visibleItems = 0;

    $(".item-container").each(function() {
        // Correctly fetch the price from data attribute
        var price = parseFloat($(this).attr("data-price"));
        // Correctly target the product name text
        var name = $(this).find(".product-name-text").text().toLowerCase();

        var matchSearch = name.indexOf(searchText) > -1;
        var matchPrice = (price >= minPrice && price <= maxPrice);

        if (matchSearch && matchPrice) {
            $(this).show();
            visibleItems++;
        } else {
            $(this).hide();
        }
    });

    // Handle "No results" display
    if(visibleItems === 0) { 
        $("#no-results").show(); 
        $("#product_list").hide(); 
    } else { 
        $("#no-results").hide(); 
        $("#product_list").show(); 
    }
}

function resetFilters() {
    $("#product_search").val('');
    $("#price-range").slider("values", [0, 500000]);
    $("#amount").val("KSh 0 - KSh 500,000");
    applyFilters();
}
</script>
</body>
</html>