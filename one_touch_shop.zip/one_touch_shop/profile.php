<?php include 'includes/session.php'; ?>
<?php
	if(!isset($_SESSION['user'])){
		header('location: index.php');
	}
?>
<?php include 'includes/header.php'; ?>
<style>
	/* Custom CSS to handle long transaction IDs on small screens */
	@media (max-width: 768px) {
		.box-body { padding: 10px; }
		h4 { font-size: 16px; }
		.trans-table { font-size: 13px; }
	}
</style>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

	<?php include 'includes/navbar.php'; ?>
	 
	  <div class="content-wrapper">
	    <div class="container">

	      <section class="content">
	        <div class="row">
	        	<div class="col-sm-12 col-md-9">
	        		<?php
	        			if(isset($_SESSION['error'])){
	        				echo "
	        					<div class='callout callout-danger'>
	        						".$_SESSION['error']."
	        					</div>
	        				";
	        				unset($_SESSION['error']);
	        			}

	        			if(isset($_SESSION['success'])){
	        				echo "
	        					<div class='callout callout-success'>
	        						".$_SESSION['success']."
	        					</div>
	        				";
	        				unset($_SESSION['success']);
	        			}
	        		?>
	        		<div class="box box-solid">
	        			<div class="box-body">
	        				<div class="col-xs-12 col-sm-3 text-center">
	        					<img src="<?php echo (!empty($user['photo'])) ? 'images/'.$user['photo'] : 'images/profile.jpg'; ?>" class="img-thumbnail" style="width: 150px; margin-bottom: 15px;">
	        				</div>
	        				<div class="col-xs-12 col-sm-9">
	        					<div class="row">
	        						<div class="col-xs-5 col-sm-4">
	        							<p><strong>Name:</strong></p>
	        							<p><strong>Email:</strong></p>
	        							<p><strong>Contact:</strong></p>
	        							<p><strong>Address:</strong></p>
	        							<p><strong>Joined:</strong></p>
	        						</div>
	        						<div class="col-xs-7 col-sm-8">
	        							<p><?php echo $user['firstname'].' '.$user['lastname']; ?>
	        								<span class="pull-right">
	        									<a href="#edit" class="btn btn-success btn-xs btn-flat" data-toggle="modal"><i class="fa fa-edit"></i> Edit</a>
	        								</span>
	        							</p>
	        							<p class="text-muted" style="word-break: break-all;"><?php echo $user['email']; ?></p>
	        							
	        							<p><?php echo (!empty($user['contact'])) ? $user['contact'] : 'Not provided'; ?></p>
	        							
	        							<p><?php echo (!empty($user['address'])) ? $user['address'] : 'Not provided'; ?></p>
	        							
	        							<p><?php echo date('M d, Y', strtotime($user['created_on'])); ?></p>
	        						</div>
	        					</div>
	        				</div>
	        			</div>
	        		</div>
	        		<div class="box box-solid">
	        			<div class="box-header with-border">
	        				<h4 class="box-title"><i class="fa fa-calendar"></i> <b>Transaction History</b></h4>
	        			</div>
	        			<div class="box-body">
	        				<div class="table-responsive">
		        				<table class="table table-bordered trans-table" id="example1">
		        					<thead>
		        						<th class="hidden"></th>
		        						<th>Date</th>
		        						<th>Transaction#</th>
		        						<th>Amount</th>
		        						<th>Details</th>
		        					</thead>
		        					<tbody>
		        					<?php
		        						$conn = $pdo->open();

		        						try{
		        							$stmt = $conn->prepare("SELECT * FROM sales WHERE user_id=:user_id ORDER BY sales_date DESC");
		        							$stmt->execute(['user_id'=>$user['id']]);
		        							foreach($stmt as $row){
		        								$stmt2 = $conn->prepare("SELECT * FROM details LEFT JOIN products ON products.id=details.product_id WHERE sales_id=:id");
		        								$stmt2->execute(['id'=>$row['id']]);
		        								$total = 0;
		        								foreach($stmt2 as $row2){
		        									$subtotal = $row2['price']*$row2['quantity'];
		        									$total += $subtotal;
		        								}
		        								echo "
		        									<tr>
		        										<td class='hidden'></td>
		        										<td>".date('M d, Y', strtotime($row['sales_date']))."</td>
		        										<td style='word-break: break-all;'>".$row['pay_id']."</td>
		        										<td><b>Ksh ".number_format($total, 2)."</b></td>
		        										<td><button class='btn btn-xs btn-flat btn-info transact' data-id='".$row['id']."'><i class='fa fa-search'></i> View</button></td>
		        									</tr>
		        								";
		        							}
		        						}
		        						catch(PDOException $e){
											echo "There is some problem: " . $e->getMessage();
										}
		        						$pdo->close();
		        					?>
		        					</tbody>
		        				</table>
	        				</div>
	        			</div>
	        		</div>
	        	</div>
	        	<div class="col-sm-12 col-md-3">
	        		<?php include 'includes/sidebar.php'; ?>
	        	</div>
	        </div>
	      </section>
	      
	    </div>
	  </div>
  
 	<?php include 'includes/footer.php'; ?>
 	<?php include 'includes/profile_modal.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
	$(document).on('click', '.transact', function(e){
		e.preventDefault();
		$('#transaction').modal('show');
		var id = $(this).data('id');
		$.ajax({
			type: 'POST',
			url: 'transaction.php',
			data: {id:id},
			dataType: 'json',
			success:function(response){
				$('#date').html(response.date);
				$('#transid').html(response.transaction);
				$('#detail').prepend(response.list);
				$('#total').html(response.total);
			}
		});
	});

	$("#transaction").on("hidden.bs.modal", function () {
	    $('.prepend_items').remove();
	});
});
</script>
</body>
</html>