<?php
	include 'includes/session.php';

	$total = 0;
	$conn = $pdo->open();

	if(isset($_SESSION['user'])){
		// Total for Logged-in User
		$stmt = $conn->prepare("SELECT * FROM cart LEFT JOIN products on products.id=cart.product_id WHERE user_id=:user_id");
		$stmt->execute(['user_id'=>$user['id']]);

		foreach($stmt as $row){
			$subtotal = $row['price'] * $row['quantity'];
			$total += $subtotal;
		}
	}
	else{
		// Total for Guest User (Session-based cart)
		if(isset($_SESSION['cart'])){
			foreach($_SESSION['cart'] as $row){
				$stmt = $conn->prepare("SELECT * FROM products WHERE id=:id");
				$stmt->execute(['id'=>$row['productid']]);
				$product = $stmt->fetch();
				$subtotal = $product['price'] * $row['quantity'];
				$total += $subtotal;
			}
		}
	}

	$pdo->close();

	// Returns the raw number to the AJAX call in cart_view.php
	echo json_encode($total);
?>