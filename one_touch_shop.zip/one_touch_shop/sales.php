<?php
	include 'includes/session.php';

	// Change from $_GET['pay'] to $_POST['checkout_direct'] 
	// This matches the form button in your cart_view.php
	if(isset($_POST['checkout_direct'])){
		
		// Create a local Order Reference since there is no external payment
		$payid = 'ORD-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 10));
		$date = date('Y-m-d');

		$conn = $pdo->open();

		try{
			// Start a transaction to ensure everything works or nothing works
			$conn->beginTransaction();

			// 1. Insert into Sales
			$stmt = $conn->prepare("INSERT INTO sales (user_id, pay_id, sales_date) VALUES (:user_id, :pay_id, :sales_date)");
			$stmt->execute(['user_id'=>$user['id'], 'pay_id'=>$payid, 'sales_date'=>$date]);
			$salesid = $conn->lastInsertId();
			
			// 2. Fetch cart items
			$stmt = $conn->prepare("SELECT * FROM cart WHERE user_id=:user_id");
			$stmt->execute(['user_id'=>$user['id']]);
			$cart_items = $stmt->fetchAll();

			// 3. Move items to details
			foreach($cart_items as $row){
				$stmt_details = $conn->prepare("INSERT INTO details (sales_id, product_id, quantity) VALUES (:sales_id, :product_id, :quantity)");
				$stmt_details->execute([
					'sales_id'   => $salesid, 
					'product_id' => $row['product_id'], 
					'quantity'   => $row['quantity']
				]);
			}

			// 4. Clear the cart
			$stmt_del = $conn->prepare("DELETE FROM cart WHERE user_id=:user_id");
			$stmt_del->execute(['user_id'=>$user['id']]);

			// Commit the changes
			$conn->commit();

			$_SESSION['success'] = 'Order placed successfully! Reference: ' . $payid;

		}
		catch(PDOException $e){
			$conn->rollBack();
			$_SESSION['error'] = "Order Failed: " . $e->getMessage();
		}

		$pdo->close();
	}
	else{
		$_SESSION['error'] = 'Please use the checkout button to place an order.';
	}
	
	header('location: profile.php');
?>