<?php 
    include 'includes/session.php'; 

    if(isset($_SESSION['admin'])){
        header('location: admin/home.php');
        exit();
    }
?>
<?php include 'includes/header.php'; ?>
<style>
    .content-wrapper { background-color: #f8f9fa; }
    
    /* Hero Section */
    .hero-section {
        background: linear-gradient(rgba(60, 141, 188, 0.9), rgba(46, 109, 164, 0.9)), url('images/banner_bg.jpg');
        background-size: cover;
        padding: 40px 0;
        margin-bottom: 20px;
        border-radius: 0 0 20px 20px;
        text-align: center;
        color: white;
    }

    /* Fixed Search Bar Styling */
    .search-box {
        background: #fff;
        padding: 5px 15px;
        border-radius: 50px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 15px auto 0;
        display: flex;
        align-items: center;
    }

    .search-box .input-group { width: 100%; border: none; }
    
    .search-input {
        border: none !important;
        box-shadow: none !important;
        height: 40px;
        font-size: 16px;
    }

    .input-group-addon {
        background: transparent !important;
        border: none !important;
        font-size: 18px;
    }

    /* Product Card Architecture */
    .product-card {
        background: #fff;
        border-radius: 10px;
        border: 1px solid #edf2f7;
        display: flex;
        flex-direction: column;
        height: 350px; 
        overflow: hidden; 
        margin-bottom: 20px;
    }

    .image-container {
        position: relative;
        height: 160px;
        background: #fff;
        padding: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-bottom: 1px solid #f8f9fa;
    }

    .product-card img { max-height: 100%; max-width: 100%; object-fit: contain; }

    .card-body {
        padding: 10px 12px;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        background: #fff;
    }

    .product-name-link {
        color: #1a202c !important;
        font-weight: 800;
        font-size: 14px;
        height: 34px; 
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-decoration: none !important;
    }

    .product-description {
        font-size: 11px;
        color: #718096;
        height: 28px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        margin-bottom: 5px;
    }

    .price-container {
        margin-top: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .price-tag { font-size: 15px; font-weight: 900; color: #2d3748; }

    /* Mobile View */
    @media (max-width: 768px) {
        .item-container { width: 50%; float: left; padding: 5px; }
        .product-card { height: 280px; }
        .image-container { height: 120px; }
        .product-description { display: none; }
    }

    .category-badge {
        position: absolute; top: 8px; left: 8px;
        background: rgba(60, 141, 188, 0.1);
        color: #3c8dbc; padding: 2px 8px;
        border-radius: 10px; font-size: 9px; font-weight: 700;
    }

    /* WHATSAPP FLOATING BUTTON CSS */
    .whatsapp-float {
        position: fixed;
        width: 60px;
        height: 60px;
        bottom: 20px;
        right: 20px;
        background-color: #25d366;
        color: #FFF;
        border-radius: 50px;
        text-align: center;
        font-size: 30px;
        box-shadow: 2px 2px 10px rgba(0,0,0,0.2);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: 0.3s;
    }
    .whatsapp-float:hover {
        background-color: #128c7e;
        color: #FFF;
        transform: scale(1.1);
    }
</style>

<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    
    <div class="content-wrapper">
        <div class="hero-section">
            <div class="container">
                <h1 style="font-weight: 800;">Modern Shopping</h1>
                <div class="search-box">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-search text-muted"></i></span>
                        <input type="text" id="product_search" class="form-control search-input" placeholder="Search for products or categories...">
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
          <section class="content" style="padding: 0 5px;">
            <h2 class="section-title" style="font-size: 18px;"><i class="fa fa-bolt"></i> New Arrivals</h2>
            <div id="product_list" class="row" style="margin: 0;">
                <?php
                    $conn = $pdo->open();
                    try{
                        $stmt = $conn->prepare("SELECT *, products.id AS prodid, products.name AS prodname, category.name AS catname FROM products LEFT JOIN category ON category.id=products.category_id ORDER BY products.id DESC");
                        $stmt->execute();
                        foreach ($stmt as $row) {
                            $image = (!empty($row['photo'])) ? 'images/'.$row['photo'] : 'images/noimage.jpg';
                            $desc = strip_tags($row['description']);
                            
                            echo "
                                <div class='col-md-3 col-xs-6 item-container'>
                                    <div class='product-card'>
                                        <div class='image-container'>
                                            <span class='category-badge'>".$row['catname']."</span>
                                            <a href='product.php?product=".$row['slug']."'>
                                                <img src='".$image."' alt='".$row['prodname']."'>
                                            </a>
                                        </div>
                                        <div class='card-body'>
                                            <a href='product.php?product=".$row['slug']."' class='product-name-link'>".$row['prodname']."</a>
                                            <div class='product-description'>".$desc."</div>
                                            <div class='price-container'>
                                                <span class='price-tag'>KSh ".number_format($row['price'], 0)."</span>
                                                <a href='product.php?product=".$row['slug']."' class='btn-cart' style='background:#3c8dbc; color:white; border-radius:5px; padding:4px 8px;'>
                                                    <i class='fa fa-arrow-right'></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
                        }
                    }
                    catch(PDOException $e){ echo "Error: " . $e->getMessage(); }
                    $pdo->close();
                ?>
            </div>
          </section>
        </div>
    </div>

    <a href="https://wa.me/254790723820?text=Hi, I have a question about your products" class="whatsapp-float" target="_blank">
        <i class="fa fa-whatsapp"></i>
    </a>

    <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>

<script>
$(document).ready(function(){
    $("#product_search").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $(".item-container").filter(function() {
            var name = $(this).find('.product-name-link').text().toLowerCase();
            var desc = $(this).find('.product-description').text().toLowerCase();
            var cat = $(this).find('.category-badge').text().toLowerCase();
            $(this).toggle(name.indexOf(value) > -1 || desc.indexOf(value) > -1 || cat.indexOf(value) > -1);
        });
    });
});
</script>
</body>
</html>