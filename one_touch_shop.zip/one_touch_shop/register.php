<?php
	include 'includes/session.php';

	if(isset($_POST['signup'])){
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$email = $_POST['email'];
		$contact = $_POST['contact']; 
		$address = $_POST['address']; 
		$password = $_POST['password'];
		$repassword = $_POST['repassword'];

		$_SESSION['firstname'] = $firstname;
		$_SESSION['lastname'] = $lastname;
		$_SESSION['email'] = $email;
		$_SESSION['contact'] = $contact;
		$_SESSION['address'] = $address;

		// ReCAPTCHA Logic
		if(!isset($_SESSION['captcha'])){
			if(!isset($_POST['g-recaptcha-response']) || empty($_POST['g-recaptcha-response'])){
				$_SESSION['error'] = 'Please check the recaptcha box';
				header('location: signup.php');	
				exit();
			}

			$captcha = $_POST['g-recaptcha-response'];
			$secret = '6LevO1IUAAAAAFCCiOHERRXjh3VrHa5oywciMKcw'; 
			
			$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$captcha);
			$responseData = json_decode($verifyResponse);

			if (!$responseData->success){
				$_SESSION['error'] = 'Please answer recaptcha correctly';
				header('location: signup.php');	
				exit();	
			}	
			else{
				$_SESSION['captcha'] = time() + (10*60);
			}
		}

		if($password != $repassword){
			$_SESSION['error'] = 'Passwords did not match';
			header('location: signup.php');
			exit();
		}
		else{
			$conn = $pdo->open();
			$stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM users WHERE email=:email");
			$stmt->execute(['email'=>$email]);
			$row = $stmt->fetch();

			if($row['numrows'] > 0){
				$_SESSION['error'] = 'Email already taken';
				header('location: signup.php');
				exit();
			}
			else{
				$now = date('Y-m-d');
				$password_hashed = password_hash($password, PASSWORD_DEFAULT);
				
				// We set status to 1 so they don't need to click an activation link
				$status = 1; 

				try{
					$stmt = $conn->prepare("INSERT INTO users (email, password, firstname, lastname, contact, address, status, created_on) VALUES (:email, :password, :firstname, :lastname, :contact, :address, :status, :now)");
					$stmt->execute([
						'email'=>$email, 
						'password'=>$password_hashed, 
						'firstname'=>$firstname, 
						'lastname'=>$lastname, 
						'contact'=>$contact, 
						'address'=>$address, 
						'status'=>$status, 
						'now'=>$now
					]);

					// Success! Clear sessions
					unset($_SESSION['firstname'], $_SESSION['lastname'], $_SESSION['email'], $_SESSION['contact'], $_SESSION['address']);

					$_SESSION['success'] = 'Account created successfully. You can now login.';
					header('location: login.php');

				}
				catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
					header('location: signup.php');
				}
				$pdo->close();
			}
		}
	}
	else{
		$_SESSION['error'] = 'Fill up signup form first';
		header('location: signup.php');
	}
?>