<?php
	include 'includes/session.php';

	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$conn = $pdo->open();

		// Fetch the sale header
		$stmt = $conn->prepare("SELECT * FROM sales WHERE id=:id");
		$stmt->execute(['id'=>$id]);
		$sale = $stmt->fetch();

		// Check if user owns this order
		if($sale['user_id'] != $user['id']){
			header('location: sales.php');
			exit();
		}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Order Invoice - <?php echo $sale['pay_id']; ?></title>
	<style>
		body { font-family: 'Helvetica', Arial, sans-serif; padding: 30px; color: #333; }
		.header { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
		.brand { font-size: 28px; font-weight: bold; text-transform: uppercase; }
		.brand span { color: #f39c12; }
		.invoice-meta { display: flex; justify-content: space-between; margin-bottom: 30px; }
		table { width: 100%; border-collapse: collapse; margin-top: 20px; }
		th { background: #f4f4f4; padding: 12px; border: 1px solid #ddd; text-align: left; }
		td { padding: 12px; border: 1px solid #ddd; }
		.text-right { text-align: right; }
		.total-row { font-size: 18px; background: #eee; font-weight: bold; }
		@media print { .no-print { display: none; } }
	</style>
</head>
<body onload="window.print();">

	<div class="header">
		<div class="brand">One<span>Touch</span> Shop</div>
		<p>Official Purchase Receipt</p>
	</div>

	<div class="invoice-meta">
		<div>
			<strong>Billed To:</strong><br>
			<?php echo $user['firstname'].' '.$user['lastname']; ?><br>
			<?php echo $user['address']; ?><br>
			<?php echo $user['contact']; ?>
		</div>
		<div class="text-right">
			<strong>Transaction ID:</strong> <?php echo $sale['pay_id']; ?><br>
			<strong>Order Date:</strong> <?php echo date('M d, Y', strtotime($sale['sales_date'])); ?>
		</div>
	</div>

	<button class="no-print" onclick="window.print()" style="margin-bottom:20px; padding:10px; background:#000; color:#fff; border:none; cursor:pointer;">Print Invoice</button>

	<table>
		<thead>
			<tr>
				<th>Product</th>
				<th class="text-right">Price</th>
				<th class="text-right">Quantity</th>
				<th class="text-right">Subtotal</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$stmt_details = $conn->prepare("SELECT * FROM details LEFT JOIN products ON products.id=details.product_id WHERE sales_id=:id");
				$stmt_details->execute(['id'=>$id]);
				$total = 0;
				foreach($stmt_details as $row){
					$subtotal = $row['price'] * $row['quantity'];
					$total += $subtotal;
					echo "
						<tr>
							<td>".$row['name']."</td>
							<td class='text-right'>KSh ".number_format($row['price'], 2)."</td>
							<td class='text-right'>".$row['quantity']."</td>
							<td class='text-right'>KSh ".number_format($subtotal, 2)."</td>
						</tr>
					";
				}
			?>
			<tr class="total-row">
				<td colspan="3" class="text-right">GRAND TOTAL</td>
				<td class="text-right">KSh <?php echo number_format($total, 2); ?></td>
			</tr>
		</tbody>
	</table>

	<p style="margin-top:50px; text-align:center; color:#888;">Thank you for shopping at One Touch Shop!</p>

</body>
</html>
<?php
		$pdo->close();
	}
	else{
		header('location: sales.php');
	}
?>